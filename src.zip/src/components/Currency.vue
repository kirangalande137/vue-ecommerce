<template>
  
</template>

<script>
import useCurrencyInput from 'vue-currency-input'
export default {

}
</script>

<style>

</style>