<template>
    <div>
        <div
            class="flex bg-gray-200 w-full h-screen items-center justify-center"
        >
            <div class="">
                <img class="" src="../assets/404-error-page.jpg" alt="" />
            </div>
        </div>
    </div>
</template>

<script>
export default {}
</script>

<style></style>
